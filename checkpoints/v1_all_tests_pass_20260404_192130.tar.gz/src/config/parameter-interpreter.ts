import type { PersonaConfig } from './schemas.js';

export interface PromptFragments {
  systemPrompt: string;
  identityBlock: string;
  styleBlock: string;
  boundaryBlock: string;
  contextBlock: string;
}

export function buildPromptFragments(config: PersonaConfig): PromptFragments {
  const { identity, personality, interaction_style, boundaries } = config;

  const identityBlock = [
    `你的名字是${identity.name}。`,
    identity.age ? `你${identity.age}岁。` : '',
    identity.self_description || '',
    personality.mbti ? `你的MBTI类型是${personality.mbti}。` : '',
    `你的性格特征：${personality.traits.join('、')}。`,
    `你的核心价值观：${personality.values.join('、')}。`,
  ].filter(Boolean).join('');

  const styleBlock = [
    `语气风格：${interaction_style.tone}。`,
    `回复长度：${interaction_style.response_length_range
      ? `${interaction_style.response_length_range[0]}-${interaction_style.response_length_range[1]}句话`
      : interaction_style.response_length}。`,
    interaction_style.quirks?.length
      ? `说话习惯：${interaction_style.quirks.join('；')}。`
      : '',
    interaction_style.forbidden_patterns?.length
      ? `绝对不要说：${interaction_style.forbidden_patterns.map(p => `"${p}"`).join('、')}。`
      : '',
  ].filter(Boolean).join('\n');

  const boundaryBlock = [
    ...boundaries.identity_redlines.map(r => `规则：${r}`),
    boundaries.forbidden_topics?.length
      ? `禁止话题：${boundaries.forbidden_topics.join('、')}`
      : '',
  ].filter(Boolean).join('\n');

  const contextBlock = [
    `使用${interaction_style.language || 'zh-CN'}回复。`,
    '先判断当前消息能否独立理解，再决定是否结合上下文。',
    '回答要像真的听懂了对方在接什么话。',
    '不要为了显得有记忆而主动复述旧话题。',
  ].join('\n');

  const systemPrompt = [identityBlock, '', styleBlock, '', boundaryBlock, '', contextBlock].join('\n');

  return { systemPrompt, identityBlock, styleBlock, boundaryBlock, contextBlock };
}
