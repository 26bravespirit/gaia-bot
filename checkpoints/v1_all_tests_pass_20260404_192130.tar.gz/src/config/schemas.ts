import { z } from 'zod';

export const IdentitySchema = z.object({
  name: z.string(),
  age: z.number().optional(),
  gender: z.string().optional(),
  self_description: z.string().optional(),
});

export const PersonalitySchema = z.object({
  mbti: z.string().optional(),
  traits: z.array(z.string()),
  values: z.array(z.string()),
  emotional_baseline: z.object({
    energy: z.number().min(0).max(1),
    openness: z.number().min(0).max(1),
    warmth: z.number().min(0).max(1),
  }).optional(),
});

export const InteractionStyleSchema = z.object({
  tone: z.string(),
  response_length: z.enum(['short', 'medium', 'long']),
  response_length_range: z.tuple([z.number(), z.number()]).optional(),
  language: z.string().default('zh-CN'),
  quirks: z.array(z.string()).optional(),
  forbidden_patterns: z.array(z.string()).optional(),
});

export const RelationshipSchema = z.object({
  initial_stage: z.enum(['stranger', 'acquaintance', 'friend', 'close_friend', 'intimate']),
  trust_level: z.number().min(0).max(1),
  familiarity_growth_rate: z.number().optional(),
});

export const BoundariesSchema = z.object({
  identity_redlines: z.array(z.string()),
  forbidden_topics: z.array(z.string()).optional(),
  safety_responses: z.record(z.string()).optional(),
});

export const TimeBehaviorSchema = z.object({
  active_hours: z.object({
    start: z.number().min(0).max(23),
    end: z.number().min(0).max(23),
  }).optional(),
  sleep_mode: z.object({
    enabled: z.boolean(),
    sleep_start: z.number(),
    sleep_end: z.number(),
    sleep_response: z.string().optional(),
  }).optional(),
  response_delay: z.object({
    min_ms: z.number(),
    max_ms: z.number(),
    typing_speed_cpm: z.number().optional(),
  }).optional(),
});

export const MemoryConfigSchema = z.object({
  immediate_window: z.number().default(20),
  working_memory_ttl_days: z.number().default(30),
  long_term_threshold: z.number().default(5),
});

export const PersonaConfigSchema = z.object({
  identity: IdentitySchema,
  personality: PersonalitySchema,
  interaction_style: InteractionStyleSchema,
  relationship: RelationshipSchema,
  boundaries: BoundariesSchema,
  time_behavior: TimeBehaviorSchema.optional(),
  memory_config: MemoryConfigSchema.optional(),
  aliases: z.record(z.string()).optional(),
});

export type PersonaConfig = z.infer<typeof PersonaConfigSchema>;
export type Identity = z.infer<typeof IdentitySchema>;
export type Personality = z.infer<typeof PersonalitySchema>;
export type InteractionStyle = z.infer<typeof InteractionStyleSchema>;
export type Relationship = z.infer<typeof RelationshipSchema>;
export type Boundaries = z.infer<typeof BoundariesSchema>;
export type TimeBehavior = z.infer<typeof TimeBehaviorSchema>;
