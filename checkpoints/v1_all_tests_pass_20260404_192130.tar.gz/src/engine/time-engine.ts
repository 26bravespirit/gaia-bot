import type { PersonaConfig } from '../config/schemas.js';

export interface TimeState {
  isActiveHours: boolean;
  isSleepMode: boolean;
  currentHour: number;
  energyLevel: number;
  replyDelayMs: number;
  sessionMessageCount: number;
}

export class TimeEngine {
  private config: PersonaConfig;
  private sessionStart: number = Date.now();
  private messageCountThisSession: number = 0;
  private lastInteractionAt: number = 0;

  constructor(config: PersonaConfig) {
    this.config = config;
  }

  updateConfig(config: PersonaConfig): void {
    this.config = config;
  }

  recordInteraction(): void {
    this.messageCountThisSession++;
    this.lastInteractionAt = Date.now();
  }

  getState(): TimeState {
    const now = new Date();
    const hour = now.getHours();
    const tb = this.config.time_behavior;

    const isActiveHours = tb?.active_hours
      ? hour >= tb.active_hours.start && hour < tb.active_hours.end
      : true;

    const isSleepMode = tb?.sleep_mode?.enabled
      ? hour >= tb.sleep_mode.sleep_start || hour < tb.sleep_mode.sleep_end
      : false;

    const baseEnergy = this.config.personality.emotional_baseline?.energy ?? 0.8;
    const hourDecay = isSleepMode ? 0.3 : (isActiveHours ? 0 : 0.15);
    const sessionDecay = Math.min(this.messageCountThisSession * 0.01, 0.2);
    const energyLevel = Math.max(0.1, baseEnergy - hourDecay - sessionDecay);

    const delay = tb?.response_delay;
    const replyDelayMs = delay
      ? delay.min_ms + Math.random() * (delay.max_ms - delay.min_ms)
      : 500 + Math.random() * 1500;

    return {
      isActiveHours,
      isSleepMode,
      currentHour: hour,
      energyLevel,
      replyDelayMs,
      sessionMessageCount: this.messageCountThisSession,
    };
  }

  getSleepResponse(): string | null {
    const state = this.getState();
    if (!state.isSleepMode) return null;
    return this.config.time_behavior?.sleep_mode?.sleep_response || null;
  }

  arbitrate(decisions: { source: string; priority: number; value: unknown }[]): unknown {
    if (!decisions.length) return null;
    decisions.sort((a, b) => b.priority - a.priority);
    return decisions[0].value;
  }
}
