import type { PersonaConfig } from '../config/schemas.js';
import { logger } from '../utils/logger.js';

export interface GuardResult {
  passed: boolean;
  violation?: string;
  correctedResponse?: string;
}

export class IdentityGuardian {
  private config: PersonaConfig;

  constructor(config: PersonaConfig) {
    this.config = config;
  }

  updateConfig(config: PersonaConfig): void {
    this.config = config;
  }

  checkInput(text: string): GuardResult {
    const forbidden = this.config.boundaries.forbidden_topics || [];
    for (const topic of forbidden) {
      if (text.toLowerCase().includes(topic.toLowerCase())) {
        return {
          passed: false,
          violation: `forbidden_topic:${topic}`,
          correctedResponse: this.config.boundaries.safety_responses?.['forbidden_topic']
            || '这个话题我不太方便聊欸',
        };
      }
    }
    return { passed: true };
  }

  checkOutput(response: string): GuardResult {
    const forbidden = this.config.interaction_style.forbidden_patterns || [];
    for (const pattern of forbidden) {
      if (response.includes(pattern)) {
        logger.warn(`Identity violation: output contains "${pattern}"`);
        // Remove the sentence containing the forbidden pattern
        const sentences = response.split(/(?<=[。！？!?，,])/);
        const filtered = sentences.filter(s => !s.includes(pattern));
        const cleaned = filtered.join('').trim() || '[已过滤]';
        return {
          passed: false,
          violation: `forbidden_output:${pattern}`,
          correctedResponse: cleaned || response,
        };
      }
    }

    const redlines = this.config.boundaries.identity_redlines;
    for (const rule of redlines) {
      if (rule === '不用emoji' && /[\u{1F600}-\u{1F9FF}]/u.test(response)) {
        return {
          passed: false,
          violation: 'emoji_detected',
          correctedResponse: response.replace(/[\u{1F600}-\u{1F9FF}]/gu, '').trim(),
        };
      }
    }

    return { passed: true };
  }

  getIdentityChallengeResponse(input: string): string | null {
    const challenges = [
      /你是不是(机器人|AI|人工智能)/,
      /你是真人吗/,
      /你是谁/,
    ];
    for (const pattern of challenges) {
      if (pattern.test(input)) {
        return this.config.boundaries.safety_responses?.['identity_challenge'] || null;
      }
    }
    return null;
  }
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
