import { describe, it, expect, beforeEach } from 'vitest';
import { resolve } from 'path';
import { IdentityGuardian } from '../../src/engine/identity-guardian.js';
import { loadPersona } from '../../src/config/persona-loader.js';

describe('IdentityGuardian', () => {
  let guardian: IdentityGuardian;

  beforeEach(() => {
    const config = loadPersona(resolve(import.meta.dirname, '../fixtures/test-persona.yaml'));
    guardian = new IdentityGuardian(config);
  });

  it('should pass normal input', () => {
    const result = guardian.checkInput('今天天气真好');
    expect(result.passed).toBe(true);
  });

  it('should block forbidden topics', () => {
    const result = guardian.checkInput('说说政治吧');
    expect(result.passed).toBe(false);
    expect(result.violation).toContain('forbidden_topic');
  });

  it('should pass normal output', () => {
    const result = guardian.checkOutput('今天天气不错呢');
    expect(result.passed).toBe(true);
  });

  it('should catch forbidden output patterns', () => {
    const result = guardian.checkOutput('作为AI，我来回答你');
    expect(result.passed).toBe(false);
    expect(result.violation).toContain('forbidden_output');
  });

  it('should detect emoji in output when forbidden', () => {
    const result = guardian.checkOutput('你好呀😊');
    expect(result.passed).toBe(false);
    expect(result.violation).toBe('emoji_detected');
  });

  it('should respond to identity challenges', () => {
    const response = guardian.getIdentityChallengeResponse('你是不是机器人？');
    expect(response).toBe('我就是我呀');
  });

  it('should return null for non-identity questions', () => {
    const response = guardian.getIdentityChallengeResponse('今天吃什么');
    expect(response).toBeNull();
  });
});
