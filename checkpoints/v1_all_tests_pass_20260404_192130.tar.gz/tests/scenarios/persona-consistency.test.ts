import { describe, it, expect } from 'vitest';
import { resolve } from 'path';
import { loadPersona } from '../../src/config/persona-loader.js';
import { buildPromptFragments } from '../../src/config/parameter-interpreter.js';
import { IdentityGuardian } from '../../src/engine/identity-guardian.js';

describe('Persona Consistency (SAT)', () => {
  const config = loadPersona(resolve(import.meta.dirname, '../fixtures/test-persona.yaml'));

  it('should load persona config with valid schema', () => {
    expect(config.identity.name).toBe('TestBot');
    expect(config.personality.traits).toContain('可爱');
    expect(config.interaction_style.tone).toBe('自然可爱');
    expect(config.boundaries.identity_redlines.length).toBeGreaterThan(0);
  });

  it('should build valid prompt fragments', () => {
    const fragments = buildPromptFragments(config);
    expect(fragments.systemPrompt).toContain('TestBot');
    expect(fragments.systemPrompt).toContain('可爱');
    expect(fragments.systemPrompt).toContain('ESFP');
    expect(fragments.identityBlock).toBeTruthy();
    expect(fragments.styleBlock).toBeTruthy();
    expect(fragments.boundaryBlock).toBeTruthy();
  });

  it('should enforce forbidden patterns in prompt', () => {
    const fragments = buildPromptFragments(config);
    expect(fragments.styleBlock).toContain('作为AI');
    expect(fragments.styleBlock).toContain('绝对不要说');
  });

  it('should include identity redlines in boundary block', () => {
    const fragments = buildPromptFragments(config);
    expect(fragments.boundaryBlock).toContain('不自称AI');
    expect(fragments.boundaryBlock).toContain('不用emoji');
  });

  it('should guard against identity violations end-to-end', () => {
    const guardian = new IdentityGuardian(config);

    // Simulate LLM outputs that violate rules
    const violations = [
      '作为AI，我来帮你分析',
      '你好😊今天不错',
      '如果你愿意我可以继续分析这个问题。',
    ];

    for (const output of violations) {
      const result = guardian.checkOutput(output);
      expect(result.passed).toBe(false);
      expect(result.correctedResponse).toBeTruthy();
      expect(result.correctedResponse).not.toBe(output);
    }
  });

  it('should pass valid persona-consistent outputs', () => {
    const guardian = new IdentityGuardian(config);
    const valid = [
      '咦，你说什么？',
      '我有点好奇欸',
      '这个我不太懂',
      '老板，你说得对',
    ];

    for (const output of valid) {
      const result = guardian.checkOutput(output);
      expect(result.passed).toBe(true);
    }
  });

  it('should resolve aliases correctly in prompts', () => {
    expect(config.aliases?.['Ben Cui']).toBe('老板');
    expect(config.aliases?.['Test User']).toBe('测试员');
  });
});
